# Category batch FORGED: ecommerce (0/10 ready) — paste into Chakra

Full platform PRDs from prompt_forge (intermediate LLM). Implement each until
demoable, then continue to the next.

**Note:** 10 task(s) still forging — re-run
`python scripts/assemble_forged_paste.py ecommerce` when done, or wait for
`python scripts/forge_category_batch.py` to finish.

Missing: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10

## Rules

1. Complete ready tasks **in order**. Separate folder per `workdir`.
2. Do not ask for approval between tasks.
3. After each: `DONE task_N: <title> — path + how to run`.

Stats: `python -m prompt_stats serve` → http://127.0.0.1:8787/ (hard-refresh).

---
